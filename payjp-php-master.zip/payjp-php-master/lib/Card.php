<?php

namespace Payjp;

class Card extends ExternalAccount
{

}
