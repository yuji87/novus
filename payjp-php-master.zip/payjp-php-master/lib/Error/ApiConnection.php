<?php

namespace Payjp\Error;

class ApiConnection extends Base
{
}
