<?php

namespace Payjp\Error;

class Authentication extends Base
{
}
