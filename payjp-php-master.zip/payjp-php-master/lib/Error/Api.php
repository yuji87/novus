<?php

namespace Payjp\Error;

class Api extends Base
{
}
